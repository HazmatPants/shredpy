# shredpy/__init__.py
from .main import shred
__version__ = "0.1.0"